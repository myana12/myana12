from django.shortcuts import render,redirect
import requests
from bs4 import BeautifulSoup
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login,logout
from login.models import Useradd,Contact
from django.contrib.auth.decorators import login_required


# Create your views here.
url="https://www.bikewale.com/bajaj-bikes/"
response=requests.get(url).content
soup=BeautifulSoup(response,'html.parser')

prices=soup.find_all('span',class_='o-eZTujG o-byFsZJ o-bkmzIL o-bVSleT')
links=soup.find_all('a',class_='o-cpnuEd o-SoIQT o-eZTujG o-fzpilz')
images=soup.find_all('img',class_='o-bXKmQE o-cgkaRG o-cQfblS o-bNxxEB o-pGqQl o-wBtSi o-bwUciP o-btTZkL o-bfyaNx o-eAZqQI')
titles=soup.find_all('h3',class_='o-jjpuv o-cVMLxW o-mHabQ o-fzpibK')
bajlinks=[]
bajprices=[]
bajtitles=[]
bajimg=[]
for i in prices:
    p1=i.text
    bajprices.append(p1)
for li in links:
    l1="https://www.bikewale.com/"+li['href']
    bajlinks.append(l1)
for img in images:
    i1=img['src']
    bajimg.append(i1)
for ti in titles:
    t1=ti.text
    bajtitles.append(t1)
mylist=zip(bajlinks,bajprices,bajtitles,bajimg)
def bajaj(request):
    return render(request,"bajaj.html",{ 'mylist':mylist})
url1="https://www.zigwheels.com/upcoming-bikes"
response1=requests.get(url1).content
soup1=BeautifulSoup(response1,'html.parser')
prices1=soup1.find_all('span',class_='fnt-18 b zm-cmn-colorBlack nm-ucDetail')
links1=soup1.find_all('div',class_='p-15 pt-10 mke-ryt rel')
images1=soup1.find_all('div',class_='clr rel mk-img-h mke-lft')
titles1=soup1.find_all('div',class_='clr rel mk-img-h mke-lft')
uplinks=[]
upprices=[]
uptitles=[]
upimg=[]
for i1 in prices1:
    n1=i1.text
    upprices.append(n1)
for li2 in links1:
    l2="https://www.zigwheels.com"+li2.a['href']
    uplinks.append(l2)
for img1 in images1:
    i2=img1.img['src']
    upimg.append(i2)
for tiw in titles1:
    t2=tiw.img['title']
    uptitles.append(t2)
mylist1=zip(uplinks,upprices,uptitles,upimg)
@login_required(login_url='login')
def bike(request):
    return render(request,"base.html",{ 'mylist1':mylist1})
def contact(request):
    return render(request,"contact.html")
url2="https://www.bikewale.com/hero-bikes/"
response2=requests.get(url2).content
soup2=BeautifulSoup(response2,'html.parser')
prices2=soup2.find_all('span',class_='o-eZTujG o-byFsZJ o-bkmzIL o-bVSleT')
links2=soup2.find_all('a',class_='o-cpnuEd o-SoIQT o-eZTujG o-fzpilz')
images2=soup2.find_all('img',class_='o-bXKmQE o-cgkaRG o-cQfblS o-bNxxEB o-pGqQl o-wBtSi o-bwUciP o-btTZkL o-bfyaNx o-eAZqQI')
titles2=soup2.find_all('h3',class_='o-jjpuv o-cVMLxW o-mHabQ o-fzpibK')
heolinks=[]
heoprices=[]
heotitles=[]
heoimg=[]
for o in prices2:
    p2=o.text
    heoprices.append(p2)
for t in links2:
    e="https://www.bikewale.com/"+t['href']
    heolinks.append(e)
for y in images2:
    z=y['src']
    heoimg.append(z)
for q in titles2:
    b=q.text
    heotitles.append(b)
mylist2=zip(heolinks,heoprices,heotitles,heoimg)
def hero(request):
    return render(request,"hero.html",{ 'mylist2':mylist2})
url3="https://www.bikewale.com/honda-bikes/"
response3=requests.get(url3).content
soup3=BeautifulSoup(response3,'html.parser')
prices3=soup3.find_all('span',class_='o-eZTujG o-byFsZJ o-bkmzIL o-bVSleT')
links3=soup3.find_all('a',class_='o-cpnuEd o-SoIQT o-eZTujG o-fzpilz')
images3=soup3.find_all('img',class_='o-bXKmQE o-cgkaRG o-cQfblS o-bNxxEB o-pGqQl o-wBtSi o-bwUciP o-btTZkL o-bfyaNx o-eAZqQI')
titles3=soup3.find_all('h3',class_='o-jjpuv o-cVMLxW o-mHabQ o-fzpibK')
honlinks=[]
honprices=[]
hontitles=[]
honimg=[]
for u in prices3:
    y=u.text
    honprices.append(y)
for v in links3:
    g="https://www.zigwheels.com"+v['href']
    honlinks.append(g)
for p in images3:
    s=p['src']
    honimg.append(s)
for j in titles3:
    i=j.text
    hontitles.append(i)
mylist3=zip(honlinks,honprices,hontitles,honimg)
def honda(request):
    return render(request,"honda.html",{'mylist3':mylist3})
def login_user(request):
    if request.method=="POST":
        username=request.POST.get("username")
        password=request.POST.get("password")
        user=authenticate(username=username,password=password)
        if user is not None:
            login(request,user)
        return redirect("home")
    return render(request,"login.html")
def register(request):
    if request.method=="POST":
        username=request.POST.get("username")
        password=request.POST.get("password")
        email=request.POST.get("email")
        c=User.objects.create_user(username=username,email=email,password=password)
        c.save()
        return redirect("login")
    return render(request,"register.html")
def logout_user(request):
    logout(request)
    return redirect("login")
def contact(request):
    if request.method=="POST":
        name=request.POST['name']
        email=request.POST['email']
        message=request.POST['message']
        c=Contact(name=name,email=email,message=message)
        c.save()
        return redirect("home")
    return render(request,"contact.html")